package practice.basic.ch06.sec09;

public class CarExample {
    public static void main(String[] args) {
    Car myCar = new Car("자동차");
    myCar.setSpeed(300);
    myCar.run();

}}
