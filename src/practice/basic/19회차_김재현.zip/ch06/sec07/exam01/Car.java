package practice.basic.ch06.sec07.exam01;

public class Car {
    String type;
    String Color;
    int price;

    public Car(String type, String color, int price) {
        this.type = type;
        Color = color;
        this.price = price;
    }
}
